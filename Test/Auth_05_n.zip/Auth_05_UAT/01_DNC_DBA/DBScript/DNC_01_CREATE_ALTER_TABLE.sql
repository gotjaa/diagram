----------------------------------------------------------------------------
-- ALTER TABLE DNC.T10_CONTACT_LIST
----------------------------------------------------------------------------
--For PROD ALTER TABLE DNC.T10_CONTACT_LIST MODIFY PERSONAL_ID varchar2(20 char) null  ;
--For PROD ALTER TABLE DNC.T10_CONTACT_LIST ADD PASSPORT_NO VARCHAR2(20 char);
--For PROD ALTER TABLE DNC.T10_CONTACT_LIST ADD BUSINESS_ID VARCHAR2(30 char);
--For PROD ALTER TABLE DNC.T10_CONTACT_LIST ADD BUSINESS_NAME VARCHAR2(200 char);
--For PROD ALTER TABLE DNC.T10_CONTACT_LIST ADD CREATE_DEP varchar2(50 char) null ;

----------------------------------------------------------------------------
-- ALTER TABLE DNC.W10_CONTACT_BULK
----------------------------------------------------------------------------
--For PROD ALTER TABLE DNC.W10_CONTACT_BULK  MODIFY PERSONAL_ID varchar2(20 char) null  ;
--For PROD ALTER TABLE DNC.W10_CONTACT_BULK ADD PASSPORT_NO VARCHAR2(20 char);
--For PROD ALTER TABLE DNC.W10_CONTACT_BULK ADD BUSINESS_ID VARCHAR2(30 char);
--For PROD ALTER TABLE DNC.W10_CONTACT_BULK ADD BUSINESS_NAME VARCHAR2(200 char);
--For PROD ALTER TABLE DNC.W10_CONTACT_BULK ADD CREATE_DEP varchar2(50 char) null ;




--For PROD ALTER TABLE DNC.W20_LEAD_PROCESS ADD COMPANY VARCHAR2(50 CHAR);
--For PROD ALTER TABLE DNC.M02_ROLE_MENU ADD ENABLED VARCHAR2(3 CHAR);

----------------------------------------------------------------------------
-- ALTER TABLE DNC.P01_CONSENT_GROUP
----------------------------------------------------------------------------
--For PROD ALTER TABLE DNC.P01_CONSENT_GROUP  MODIFY CONSENT_GROUP_NAME varchar2(150 char);


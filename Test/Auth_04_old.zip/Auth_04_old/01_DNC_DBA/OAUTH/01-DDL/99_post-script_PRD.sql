set define off
-- post-script
col server for a13
col instance for a10
col language for a13
col date_format for a25
col run_by_db for a10
col run_by_os for a10
col run_from for a13
col run_sid for a8
select 'HOINTDBS01A.TISCONET.COM', 'CPSPRD',
sys_context('userenv','server_host') as server,
sys_context('userenv','instance_name') as instance,
sys_context('userenv','lang') as language,
sys_context('userenv','nls_date_format') as date_format,
sys_context('userenv','session_user') as run_by_db ,
sys_context('userenv','os_user') as run_by_os ,
sys_context('userenv','host') as run_from,
sys_context('userenv','sid') as run_sid
from dual;
select owner,object_type,status,count(1) as "#obj_effect" from dba_objects
where last_ddl_time > trunc(sysdate)
group by owner,object_type,status;
select owner, object_type, object_name,created, last_ddl_time,timestamp,status  from  dba_objects
where last_ddl_time > trunc(sysdate);
select s.owner,s.tablespace_name, sum(bytes)/1024/1024 as size_MB
from dba_segments s where s.owner in ('OAUTH')
group by s.owner,s.tablespace_name order by 1,2;
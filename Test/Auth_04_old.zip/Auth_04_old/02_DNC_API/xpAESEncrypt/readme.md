# xpAESEncrypt version 1.0.0.0
For properties file encryption of [Java Spring Boot New Framework project](https://apollo.tisconet.com/TFW/Maven-Template/maven-template.git).


## Includes
* **BASE64 key generator**
* **PBE with SHA256 encryption** - Compatible with [Java Spring Boot New Framework project](https://apollo.tisconet.com/TFW/Maven-Template/maven-template.git)
* **AES256 encryption**


## Genkey.bat
Generate BASE64 encryption key

1. Set parameter in `Genkey.bat` file - 
    ```
	java com.tisconet.security.CryptoKey [key size (bits)]
	```
    For [Java Spring Boot New Framework project](https://apollo.tisconet.com/TFW/Maven-Template/maven-template.git) use **256 bits** key.
    
2. Output -	if (key size == 256) ? `keyFile256.txt` : `keyFile.txt`

3. For [Java Spring Boot New Framework project](https://apollo.tisconet.com/TFW/Maven-Template/maven-template.git), Set key file's location in `security.properties`, such as
```
key.file=C:\\keys\\keyFile256.txt
```

## Encrypt.bat 
Generate encrypted properties file from properties file and key file

1. Create **.properties** file with parameters and values that will be encrypt in format - 
  * For **Java Spring Boot New Framework project** (PBE with SHA256 encryption), Add `_PBEWITHSHA256` after parameter's name, such as
      * [parameter's name]**_PBEWITHSHA256**=[parameter's value]
  * For AES256 encryption
      * [parameter's name]=[parameter's value]
	
2. Set parameter in `Encrypt.bat` file -
    ```
    java com.tisconet.security.App [key filename] [.properties's filename]  > encrypt.log
    ```
	or use default filename,
    ```
    java com.tisconet.security.App keyFile256.txt password256.properties  > encrypt.log
    ```
	
3. Output - `*.properties.enc` and `encrypt.log`

4. Copy the encrypted value to .properties file of [Java Spring Boot New Framework project](https://apollo.tisconet.com/TFW/Maven-Template/maven-template.git) with `{cipher}` prefix, such as
    ```
    spring.datasource.password={cipher}WgtSLBteQ+N0gy3DafUltO2wQmgWlIlejcwj3eLyr2A=
    ```


## Decrypt.bat
Test the encrypted properties

1. Set parameter in `Decrypt.bat` file -
    ```
    java com.tisconet.security.DecryptPBEWITHSHA256 [key filename] [.properties.enc's filename]  > decrypt.log
    ```
	
2. Output - `*.properties.dec` and `decrypt.log`

3. `*.properties.dec` must be like `*.properties filename`.

